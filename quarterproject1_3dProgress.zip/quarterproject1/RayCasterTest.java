
//version 1 of the raycaster - initial raycasting setup + intuition 
public class RayCasterTest
{
    int[][] mapTest = {
    {1,1,1,1,1,1,1,1},
    {1,0,0,0,0,0,0,1},
    {1,0,0,1,0,0,0,1},
    {1,0,0,1,0,1,0,1},
    {1,0,0,0,0,1,0,1},
    {1,1,1,1,1,1,1,1} 
    };
    // instance variables - replace the example below with your own
    private double playerX;
    private double playerY;
    private double playerD; 
    private double projX;
    private double projY;
    private double pfov;
    

    /**
     * Constructor for objects of class RayCaster
     */
    public RayCasterTest()
    {
        playerX = 1;
        playerY = 3;
        playerD = 0;
        pfov = Math.toRadians(60); 
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    
    //the following method is in degrees
    public double castRay(double rangle)
    {
        double newRangle = Math.toRadians(rangle);
        double rayX = playerX;
        double rayY = playerY;
        double increment = 0.01;
        
        while (true){
            rayX += Math.cos(newRangle)*increment;
            rayY += Math.sin(newRangle)*increment;
            int mapX = (int)rayX;
            int mapY = (int)rayY;
            
            if (mapTest[mapY][mapX] == 1){
                double dx = rayX - playerX;
                double dy = rayY - playerY;
                
                return Math.sqrt(dx*dx + dy*dy);
            }
            
        }
    }
    
    public void rayCasting(){
        int screenWidth = 800;
        for (int x = 0; x < screenWidth; x++) {
            double rayAngle = playerD - pfov / 2 + ((double)x / screenWidth) * pfov;
            double distance = castRay(rayAngle);
            System.out.println(distance);
        }
    }
    
    public void testGetter(){
        double gg = castRay(30);
        System.out.print(gg);
    }

}
