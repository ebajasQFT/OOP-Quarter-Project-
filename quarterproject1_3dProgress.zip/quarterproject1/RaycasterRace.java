import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class RaycasterRace extends JPanel implements ActionListener, KeyListener {

    //screen initializing 
    static final int renderWidth = 320;
    static final int renderHeight = 200;

    static final int scale = 3;

    static final int screenWidth =
            renderWidth * scale;

    static final int screenHeight =
            renderHeight * scale;
    
    BufferedImage carSprite;
    // Low-resolution image we render the game into
    BufferedImage frame = new BufferedImage(renderWidth,renderHeight, BufferedImage.TYPE_INT_RGB);

    // world / track

    static final int mapSize = 1024;

    BufferedImage trackMap = new BufferedImage(mapSize,mapSize,BufferedImage.TYPE_INT_RGB);

    BufferedImage roadMask =new BufferedImage(mapSize,mapSize,BufferedImage.TYPE_BYTE_BINARY);

    //car initialization
    double carX = 512;
    double carY = 160;

    //radian angles
    double carAngle = 0;

    double speed = 0;

    double cameraHeight = 30;

    int horizon = 80;

    double fov = Math.toRadians(70);
    
    boolean up;
    boolean down;
    boolean left;
    boolean right;

    Timer timer;

    public RaycasterRace() {

        setPreferredSize(new Dimension(screenWidth,screenHeight));

        setFocusable(true);

        addKeyListener(this);

        createTrack();
        
        try {
            carSprite = ImageIO.read(new File("car.png"));
        } 
        catch(IOException e){
            e.printStackTrace();
        }

        timer = new Timer(16, this);
        timer.start();
    }

    
    // track method to create it 

    void createTrack() {

        Graphics2D g = trackMap.createGraphics();

        // Grass
        g.setColor(new Color(40, 150, 50));

        g.fillRect(0,0,mapSize,mapSize);

        // Road
        g.setStroke(new BasicStroke(180,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));

        g.setColor(new Color(80, 80, 80));

        g.drawOval(160,160,704,704);

        // Center line
        g.setStroke(new BasicStroke(5));

        g.setColor(Color.YELLOW);

        g.drawOval(160,160,704,704);

        g.dispose();

        Graphics2D mask =
                roadMask.createGraphics();

        mask.setColor(Color.BLACK);

        mask.fillRect(0,0,mapSize,mapSize);

        mask.setStroke(new BasicStroke(180,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));

        mask.setColor(Color.WHITE);

        mask.drawOval(160,160,704,704);

        mask.dispose();
    }

    
    // Update physics

    void updateCar() {

        // Accelerate
        if (up) {
            speed += 0.2;
        }

        // Reverse / brake
        if (down) {
            speed -= 0.1;
        }

        // Natural friction
        speed *= 0.97;

        // Maximum speeds
        speed = Math.max(-5, Math.min(20, speed));

        // Steering becomes meaningful while moving.
        if (Math.abs(speed) > 0.05) {

            if (left) {
                carAngle -= 0.025;
            }

            if (right) {
                carAngle += 0.025;
            }
        }

        
        double dx =Math.cos(carAngle) * speed;

        double dy =Math.sin(carAngle) * speed;

        carX += dx;
        carY += dy;

        // Grass slowing the car down (probably change this becasue it keeps
        //multiplying; find a good value to set the speed to immediately after
        //gradually slowing down
        if (!isRoad(carX, carY)) {
            speed *= 0.90;
        }
    }

    boolean isRoad(double x, double y) {

        int ix = (int)x;
        int iy = (int)y;

        if (ix < 0 ||iy < 0 ||ix >= mapSize ||iy >= mapSize) {

            return false;
        }

        int color =
                roadMask.getRGB(ix, iy)
                & 0xFFFFFF;

        return color != 0;
    }

    void drawCar(Graphics g) {

        if (carSprite == null) {
            return;
        }

        int carWidth = 600;
        int carHeight = 350;
        int carScreenX = screenWidth / 2- carWidth / 2;
        int carScreenY =screenHeight- carHeight+20;
        g.drawImage(carSprite,carScreenX,carScreenY,carWidth,carHeight,null);
    }

    void renderWorld() {

        
        // Calculate focal length
        //
        // f = (W/2)/tan(FOV/2)

        double focalLength =(renderWidth / 2.0)/Math.tan(fov / 2.0);
        // Sky
        int skyColor =new Color(100, 180, 255).getRGB();

        for (int y = 0; y < horizon; y++) {

            for (int x = 0;x < renderWidth;x++) {

                frame.setRGB(x,y,skyColor);
            }
        }


        //plyaer direction vectors
        
        double forwardX = Math.cos(carAngle);

        double forwardY = Math.sin(carAngle);

        double rightX =-Math.sin(carAngle);

        double rightY =Math.cos(carAngle);

        // Render every ground pixel

        for (int screenY = horizon + 1;screenY < renderHeight;screenY++) {

            double v = screenY - horizon;
            // Ground distance:
            //
            // d = h*f/v

            double distance =(cameraHeight * focalLength)/ v;


            for (int screenX = 0;screenX < renderWidth;screenX++) {
                double u =screenX- renderWidth / 2.0;
                // Sideways world distance:
                //
                // s = u*d/f
                // thsi denotes the difference between the center and the acutal
                //sideways distance; repeat for veritcal columns
                //and also induce the same types of caluclations; 
                //in the final result, add their direction vectors times simulated distance.
                double sideways =u * distance/ focalLength;

                double worldX = carX + (forwardX * distance) + (rightX * sideways);

                double worldY = carY+ (forwardY * distance) + (rightY * sideways);


                int mapX = (int)worldX;
                int mapY = (int)worldY;

                int color;

                if (mapX >= 0 &&mapY >= 0 &&mapX < mapSize &&mapY < mapSize) {

                    color =trackMap.getRGB(mapX,mapY);

                } 
                else {

                    color =new Color(20,100,30).getRGB();
                }


                frame.setRGB(screenX,screenY,color);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        updateCar();

        renderWorld();

        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);
        g.drawImage(frame,0,0,screenWidth,screenHeight,null);
        
        drawCar(g);

    }

    @Override
    public void keyPressed(KeyEvent e) {

        switch (e.getKeyCode()) {

            case KeyEvent.VK_W:
                up = true;
                break;

            case KeyEvent.VK_S:
                down = true;
                break;

            case KeyEvent.VK_A:
                left = true;
                break;

            case KeyEvent.VK_D:
                right = true;
                break;

        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

        switch (e.getKeyCode()) {

            case KeyEvent.VK_W:
                up = false;
                break;

            case KeyEvent.VK_S:
                down = false;
                break;

            case KeyEvent.VK_A:
                left = false;
                break;

            case KeyEvent.VK_D:
                right = false;
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    //main method; everything ran here 
    public static void main(String[] args) {

        JFrame window =new JFrame("3d Racer!");

        RaycasterRace game =new RaycasterRace();

        window.add(game);

        window.pack();

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        window.setLocationRelativeTo(null);

        window.setVisible(true);

        game.requestFocusInWindow();
    }
}